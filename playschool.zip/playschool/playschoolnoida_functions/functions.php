<?php
$con=mysqli_connect("localhost","root","","playschool");


if  (mysqli_connect_errno() )
    {
         
		 echo  "failed to connect" . mysqli_connect_error();
	}	 
	
//getting vision	
function getVision()  {
      
            global $con;
      			 
            $get_vision = "select  * from vision";
			
			$run_vision = mysqli_query($con, $get_vision);
			
			while  ($row_vision = mysqli_fetch_array($run_vision)) {
			
			          $vision_id  = $row_vision['vision_id'];
			          $vision_line  = $row_vision['vision_line'];
					  
		    		  
			echo "<small>$vision_line</small>";
			
			
			}
			
}	

//getting 1st block quote
function getQuoteOne()  {
      
            global $con;
      			 
            $get_quoteone = "select  * from quoteone";
			
			$run_quoteone= mysqli_query($con, $get_quoteone);
			
			while  ($row_quoteone = mysqli_fetch_array($run_quoteone)) {
			
			          $quoteone_id  = $row_quoteone['quoteone_id'];
			          $quoteone_line  = $row_quoteone['quoteone_line'];
			          $quoteone_footer  = $row_quoteone['quoteone_footer'];
					  
		    		  
			echo "<p>$quoteone_line</p><footer>$quoteone_footer</footer>";
			
			
			}
			
}	

//getting thought 2
function getQuoteTwo()  {
      
            global $con;
      			 
            $get_quotetwo = "select  * from quotetwo";
			
			$run_quotetwo= mysqli_query($con, $get_quotetwo);
			
			while  ($row_quotetwo = mysqli_fetch_array($run_quotetwo)) {
			
			          $quotetwo_id  = $row_quotetwo['quotetwo_id'];
			          $quotetwo_line  = $row_quotetwo['quotetwo_line'];
			          $quotetwo_footer  = $row_quotetwo['quotetwo_footer'];
					  
		    		  
			echo "<p>$quotetwo_line</p><footer>$quotetwo_footer</footer>";
			
			
			}
			
}	


function getQuoteThree()  {
      
            global $con;
      			 
            $get_quotethree = "select  * from quotethree";
			
			$run_quotethree= mysqli_query($con, $get_quotethree);
			
			while  ($row_quotethree = mysqli_fetch_array($run_quotethree)) {
			
			          $quotethree_id  = $row_quotethree['quotethree_id'];
			          $quotethree_line  = $row_quotethree['quotethree_line'];
			          $quotethree_footer  = $row_quotethree['quotethree_footer'];
					  
		    		  
			echo "<p>$quotethree_line</p><footer>$quotethree_footer</footer>";
			
			
			}
			
}	
	
//getting carousel images


 function getGallery() {   

    
 
     global $con;
	 
	   $get_gallery = "select * from gallery ";
	     
		$run_gallery = mysqli_query($con, $get_gallery);
		
		while($row_gallery = mysqli_fetch_array($run_gallery)) {
		
		        $img_id= $row_gallery['id'];
		        $img_heading= $row_gallery['heading'];
		        $img_caption= $row_gallery['caption'];
		      
		        $img_gallery= $row_gallery['image'];
				
				
				echo "
				
				        <div class='item'>
  						<img src='playschoolnoida_admin/image/$img_gallery' class='img-responsive' alt='Text of the image'>
  						<div class='carousel-caption'>
  							<h3>$img_heading</h3>
  							<p>$img_caption</p>
  						</div>
  					</div>
				
				
				";
		
		}
	}
  


	
	
	
	
	
	
	
	

//getting programme playgroup

function getPlaygroup()  {
      
            global $con;
      			 
            $get_playgroup = "select  * from prog_playschool";
			
			$run_playgroup = mysqli_query($con, $get_playgroup);
			
			while  ($row_playgroup = mysqli_fetch_array($run_playgroup)) {
			
			          $playgroup_id  = $row_playgroup['playgroup_id'];
			          $playgroup_detail  = $row_playgroup['playgroup_detail'];
					  
		    		  
			echo "<p>$playgroup_detail</p>";
			
			
			}
			
}

// getting programme lkg section

function getLkg()  {
      
            global $con;
      			 
            $get_lkg = "select  * from prog_lkg";
			
			$run_lkg = mysqli_query($con, $get_lkg);
			
			while  ($row_lkg = mysqli_fetch_array($run_lkg)) {
			
			          $lkg_id  = $row_lkg['lkg_id'];
			          $lkg_detail  = $row_lkg['lkg_detail'];
					  
		    		  
			echo "<p>$lkg_detail</p>";
			
			
			}
			
}

//getting programme ukg section

function getUkg()  {
      
            global $con;
      			 
            $get_ukg = "select  * from prog_ukg";
			
			$run_ukg = mysqli_query($con, $get_ukg);
			
			while  ($row_ukg = mysqli_fetch_array($run_ukg)) {
			
			          $ukg_id  = $row_ukg['ukg_id'];
			          $ukg_detail  = $row_ukg['ukg_detail'];
					  
		    		  
			echo "<p>$ukg_detail</p>";
			
			
			}
			
}

//Request Call Back



        if(isset($_POST['callback']))  {
                             
							 
					    //getting text data from the fields		 
                              $call_name = $_POST['name'];
                              $call_email= $_POST['email'];
                              $call_contact = $_POST['contact'];
                              
                              												
						 $insert_callerdata = "insert into callback	 (name,email,contact)  values  ('$call_name', '$call_email','$call_contact')";
				
						   $insert_data = mysqli_query($con, $insert_callerdata);
						  
						  if($insert_data) {
						  
						  
             				echo"<script>alert ('We will call you as soon as possible.')</script>";
             				echo"<script>window.open('index.php','_self')</script>";
							
							 }
				}		  
				
				
//Admission form

        if(isset($_POST['admission']))  {
                             
							 
					    //getting text data from the fields		 
                              $student_name = $_POST['studentname'];
                              $parent_name = $_POST['parentname'];
                              $parent_email= $_POST['parentemail'];
                              $parent_contact = $_POST['parentcontact'];
                              $parent_message = $_POST['parentmessage'];
                                                           							  
						
						 $insert_parentdata = "insert into admission	 (studentname,parentname,parentemail,parentcontact,parentmessage)  
						 values  ('$student_name', '$parent_name','$parent_email','$parent_contact','$parent_message')";
				
						   $insert_guardiandata = mysqli_query($con, $insert_parentdata);
						  
						  if($insert_guardiandata) {
						  
						  
             				echo"<script>alert ('Congratulation reach the center with document . ')</script>";
             				echo"<script>window.open('index.php','_self')</script>";
							
							 }
				}		  				

				

			
			
	  
  ?>