<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="Wiredwiki App">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
</head>

<body>

<h2>View all images here</h2>

<table  class="table table-hover">

	 <thead>
              <tr>
 
                      <th> id</th> 
                      <th>Image</th> 
                      <th>Heading</th> 
                      <th>Caption</th> 
                     <th>Edit</th>  
	             </tr>
				 
		</thead>		 

<?php

    include("db.php");

            $get_img = "select* from gallery";
			
			$run_img =mysqli_query($con, $get_img);
			
			$i=1;
			
			while ($row_img = mysqli_fetch_array($run_img)) {
			
			
			$img_id = $row_img['id'];
			$img = $row_img['image'];
			$img_heading = $row_img['heading'];
			$img_caption = $row_img['caption'];
			


?>				 

<tbody>
     <tr>

             <td><?php  echo $i++;?></td>	    
             <td><img src="image/<?php  echo $img ;?>" width="60px" height="60px"></td>	
               <td><?php echo $img_heading; ?></td>			 
               <td><?php echo $img_caption; ?></td>			 
              <td><a href="index.php?edit_gallery=<?php echo $img_id;?>" class="btn btn-default"><span class="glyphicon glyphicon-pencil">Edit</span></a></td>			 
             	  
				 
			</tr>

</tbody>



<?php }?>

</body>
</html>