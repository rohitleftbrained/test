<!DOCTYPE>
<?php
include("db.php");

 $get_vision = "select* from vision";
			
			$run_playgroup =mysqli_query($con, $vision);
			
			while ($row_vision = mysqli_fetch_array($run_vision)) {
			
			
			$vision_id = $row_vision['vision_id'];
			$vision_line = $row_vision['vision_line'];
			
			
			}

?>

<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="playschoolnoida">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
</head>

<body>

<?php

include("db.php");

 

    if(isset($_GET['edit_vision'])) {
	
	$edit_id = $_GET['edit_vision'];
	
	$select_vision = "select * from vision  where vision_id='$edit_id' ";
	
	$run_query = mysqli_query($con, $select_vision);
	
	while ($row_vision = mysqli_fetch_array($run_query)) {
	
	          $vision_id = $row_vision['vision_id'];
	          $vision_line = $row_vision['vision_line'];
	         
	}

}
?>

                   <h2>Edit Your Vision Section</h2>
                 <form action="index.php?edit_vision=<?php echo $edit_id; ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
               
			     <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="text" class="form-control" id="user-name" name="vision_line" value="<?php  echo $vision_line; ?>" />
                   </div>
                  </div><!-- End form group -->
			 
			    <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="submit" class="btn btn-primary" name="update" value="EDIT">Edit</button>
                </div>
              </div>
									 
                 </form>
				 
		


                <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>		
				 
</body>
</html>

              <?php
			     
				 
                         if(isset($_POST['update']))  {
                             
							 
					    //getting text data from the fields
                              $update_id = $vision_id;						
                              $vision_line = $_POST['vision_line'];

						 $update_line = "update  vision set vision_line='$vision_line'  where  vision_id='$update_id'  ";
				
						  $update_vision = mysqli_query($con, $update_line);
						  
						  if($update_vision) {
						  
						  
             				echo"<script>alert ('vision has been updated.')</script>";
             				echo"<script>window.open('index.php?edit_vision' ,'_self')</script>";
							
							}
						  
}
                      ?>








						   

	 