<?php

include("db.php");


     if(isset($_GET['delete_admission'])) {
	 
	         $delete_id = $_GET['delete_admission'];
			 
			 $delete_admission ="delete from admission where admission_id='$delete_id'";
			 
			 $run_delete = mysqli_query($con, $delete_admission);
			 
			 echo "<script>alert('Admission application has been deleted')</script>";
			 
			 echo "<script>window.open('../index.php?view_admission','_self')</script>";
			 
			 
			 }


?>