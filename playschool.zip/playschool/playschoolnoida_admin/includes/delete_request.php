<?php

include("db.php");


     if(isset($_GET['delete_request'])) {
	 
	         $request_id = $_GET['delete_request'];
			 
			 $delete_request ="delete from callback where id='$request_id'";
			 
			 $run_request = mysqli_query($con, $delete_request);
			 
			 echo "<script>alert('Call Back has been deleted')</script>";
			 
			 echo "<script>window.open('../index.php?view_callback','_self')</script>";
			 
			 
			 }


?>