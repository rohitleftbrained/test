<?php
$con=mysqli_connect("localhost","root","","playschool");


if  (mysqli_connect_errno() )
    {
         
		 echo  "failed to connect" . mysqli_connect_error();
	}	 



?>