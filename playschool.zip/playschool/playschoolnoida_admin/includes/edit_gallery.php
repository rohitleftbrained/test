<!DOCTYPE>
<?php
include("db.php");

 $get_image = "select* from gallery";
			
			$run_image =mysqli_query($con, $get_image);
			
			while ($row_image = mysqli_fetch_array($run_image)) {
			
			
			$image_id = $row_image['id'];
			$image_heading = $row_image['heading'];
			$image_caption = $row_image['caption'];
			$image = $row_image['image'];
			
			
			}

?>

<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="playschoolnoida">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
</head>

<body>

<?php

include("db.php");

 

    if(isset($_GET['edit_gallery'])) {
	
	$edit_id = $_GET['edit_gallery'];
	
	$select_gallery = "select * from gallery  where id='$edit_id' ";
	
	$run_query = mysqli_query($con, $select_gallery);
	
	while ($row_image = mysqli_fetch_array($run_query)) {
	
	          $image_id = $row_image['id'];
	          $image_heading = $row_image['heading'];
	          $image_caption = $row_image['caption'];
			  $image = $row_image['image'];
	         
	}

}
?>

                   <h2>Edit Your Gallery Section</h2>
                 <form action="index.php?edit_gallery=<?php echo $edit_id; ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
               
			     <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="text" class="form-control" id="heading" name="heading"   value="<?php  echo $image_heading; ?>" />
		
                   </div>
                  </div><!-- End form group -->
				  
				  
				  <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="text" class="form-control" id="caption" name="caption"  value="<?php  echo $image_caption; ?>"  />
						   
                   </div>
                  </div><!-- End form group -->
				  
				  <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="file" class="form-control" id="image" name="image"  /><img src ="image/<?php echo $image; ?>"  width="60" height="60" />
                   </div>
                  </div><!-- End form group -->
			 
			    <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="submit" class="btn btn-primary" name="update_gallery" value="EDIT">Save Changes</button>
                </div>
              </div>
									 
                 </form>
				 
		


                <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>		
				 
</body>
</html>

              <?php
			     
				 
                         if(isset($_POST['update_gallery']))  {
                             
							 
					    //updating text data from the fields
                              $update_id = $image_id;						
                              $image_heading = $_POST['heading'];
                              $image_caption = $_POST['caption'];
                             
							  
							  
						//updating the image from the field

                         $gallery_image = $_FILES['image']['name'];
                          $gallery_image_tmp = $_FILES['image']['tmp_name'];	
                          
						   move_uploaded_file($gallery_image_tmp,"image/$gallery_image");  

						 $update_image = "update  gallery set heading='$image_heading',caption='$image_caption',image='$gallery_image'  where  id='$update_id'  ";
				
						  $update_img = mysqli_query($con, $update_image);
						  
						  if($update_img) {
						  
						  
             				echo"<script>alert ('Gallery has been updated.')</script>";
             				echo"<script>window.open('index.php?view_gallery' ,'_self')</script>";
							
							}
						  
}
                      ?>








						   

	 