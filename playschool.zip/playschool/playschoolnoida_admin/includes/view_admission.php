<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="Wiredwiki App">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
</head>

<body>

<h2>Admission Form applications</h2>

<table  class="table table-hover">

	 <thead>
              <tr>
 
                      <th> id</th> 
                      <th>Student Name</th> <!--bhai table ki heading dikhaengi-->
                      <th>Parent Name</th> 
                      <th>Parent Email</th>
                      <th>Parent Contact</th>
                      <th>Message</th>
                      <th>Delete</th>  
	             </tr>
				 
		</thead>		 

<?php

    include("db.php");

            $get_admission = "select* from admission";//yeh maal tere kaam ka hain isse padh
			
			$run_admission =mysqli_query($con, $get_admission);
			
			$i=1;// yeh id waali problem jo kots se pooch rha tha uska sol.
			
			while ($row_admission = mysqli_fetch_array($run_admission)) {//data fetch karr rhe
			
			
			$admission_id = $row_admission['admission_id'];//database mein jo rows ka naam rkha hain bracket mein hain
			$student_name = $row_admission['studentname'];
			$parent_name = $row_admission['parentname'];
			$parent_email = $row_admission['parentemail'];
			$parent_contact = $row_admission['parentcontact'];
			$parent_message = $row_admission['parentmessage'];
			


?>				 

<tbody>
     <tr>

             <td><?php  echo $i++;?></td>	    
             <td><?php  echo $student_name;?></td>	  
             <td><?php  echo $parent_name;?></td>	  
             <td><?php  echo $parent_email;?></td>	  
             <td><?php  echo $parent_contact;?></td>	  	 
             <td><?php  echo $parent_message;?></td><!-- jo niche link mein php peli hain neeche id no. dikta hain mouse uss link par lejaane par bina click kare-->	  	 
              <td><a href="includes/delete_admission.php?delete_admission=<?php echo $admission_id;?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove">Delete</span></a></td>			 
             <td></td>	  <!--uper jo link mein php peli hain neeche id no. dikta hain mouse uss link par lejaane par bina click kare-->
				 
			</tr>

</tbody>



<?php }?>

</body>
</html>