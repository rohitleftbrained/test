<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="Wiredwiki App">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
</head>

<body>

<h2>View all Request Call here</h2>

<table  class="table table-hover">

	 <thead>
              <tr>
 
                      <th> id</th> 
                      <th>Name</th> 
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Delete</th>  
	             </tr>
				 
		</thead>		 

<?php

    include("db.php");

            $get_requestcall = "select* from callback";
			
			$run_requestcall =mysqli_query($con, $get_requestcall);
			
			$i=1;
			
			while ($row_requestcall = mysqli_fetch_array($run_requestcall)) {
			
			
			$call_id = $row_requestcall['id'];
			$call_name = $row_requestcall['name'];
			$call_email = $row_requestcall['email'];
			$call_contact = $row_requestcall['contact'];
			


?>				 

<tbody>
     <tr>

             <td><?php  echo $i++;?></td>	  
             <td><?php  echo $call_name;?></td>	  
             <td><?php  echo $call_email;?></td>	  
             <td><?php  echo $call_contact;?></td>	  	 
              <td><a href="includes/delete_request.php?delete_request=<?php echo $call_id;?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove">Delete</span></a></td>			 
             <td></td>	  
				 
			</tr>

</tbody>



<?php }?>

</body>
</html>