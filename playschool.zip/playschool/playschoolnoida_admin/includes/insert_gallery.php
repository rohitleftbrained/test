<!DOCTYPE>
<?php
include("db.php");

?>

<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="playschoolnoida">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
</head>

<body>



                   <h2>Insert image</h2>
                 <form action="index.php?insert_gallery" class="form-horizontal" method="post" enctype="multipart/form-data">
               
			     <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="text" class="form-control" id="heading" name="heading" placeholder="heading"  />
                   </div>
                  </div><!-- End form group -->
				  
				  
				  <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="text" class="form-control" id="caption" name="caption" placeholder="caption"  />
                   </div>
                  </div><!-- End form group -->
				  
				  <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="file" class="form-control" id="image" name="image"  />
                   </div>
                  </div><!-- End form group -->
			 
			    <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="submit" class="btn btn-primary" name="insert_gallery" value="EDIT">Edit</button>
                </div>
              </div>
									 
                 </form>
				 
		


                <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>		
				 
</body>
</html>

               <?php
			     
				 
                         if(isset($_POST['insert_gallery']))  {
                             
							 
					    //getting text data from the fields		 
                              $image_heading = $_POST['heading'];
                              $image_caption = $_POST['caption'];
                             
                              
							  
						//getting the image from the field

                         $gallery_image = $_FILES['image']['name'];
                          $gallery_image_tmp = $_FILES['image']['tmp_name'];	
                          
						   move_uploaded_file($gallery_image_tmp,"image/$gallery_image");

						 $insert_gallery = "insert into gallery
						  (heading,caption,image)  values
						  ('$image_heading','$image_caption','$gallery_image')";
				
						   $insert_image = mysqli_query($con, $insert_gallery);
						  
						  if($insert_image) {
						  
						  
             				echo"<script>alert (' Gallery has been updated')</script>";
             				echo"<script>window.open('index.php?insert_gallery','_self')</script>";
							
							}
						  
}
                      ?>








						   

	 

