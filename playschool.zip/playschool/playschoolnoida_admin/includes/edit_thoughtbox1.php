<!DOCTYPE>
<?php
include("db.php");

 $get_quoteone = "select* from quoteone";
			
			$run_quoteone =mysqli_query($con, $get_quoteone);
			
			while ($row_quoteone = mysqli_fetch_array($run_quoteone)) {
			
			
			$quoteone_id = $row_quoteone['quoteone_id'];
			$quoteone_line = $row_quoteone['quoteone_line'];
			$quoteone_footer = $row_quoteone['quoteone_footer'];
			
			
			}

?>

<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="playschoolnoida">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
	
	<script src="//tinymce.cachefly.net/4.2/tinymce.min.js"></script>
          <script>tinymce.init({selector:'textarea'});</script>
</head>

<body>

<?php

include("db.php");

 

    if(isset($_GET['edit_thoughtbox1'])) {
	
	$editone_id = $_GET['edit_thoughtbox1'];
	
	$select_quoteone = "select * from quoteone  where quoteone_id='$editone_id' ";
	
	$run_query = mysqli_query($con, $select_quoteone);
	
	while ($row_quoteone = mysqli_fetch_array($run_query)) {
	
	          $quoteone_id = $row_quoteone['quoteone_id'];
	          $quoteone_line = $row_quoteone['quoteone_line'];
	          $quoteone_footer = $row_quoteone['quoteone_footer'];
	         
	}

}
?>

                   <h2>Edit Your Thoughtbox1 Section</h2>
                 <form action="index.php?edit_thoughtbox1=<?php echo $editone_id; ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
               
			      <div class="form-group">
                
                <div class="col-lg-10">
                  <textarea  id="user-message" rows="3" cols="20"class="form-control"   name="quoteone_line" ><?php  echo $quoteone_line; ?></textarea>
                </div>
              </div><!-- End form group -->
			   
			     <div class="form-group">
                
                  <div class="col-lg-12">
                           <input type="text" class="form-control" id="user-name" name="quoteone_footer" value="<?php  echo $quoteone_footer; ?>" />
                   </div>
                  </div><!-- End form group -->
			 
			    <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="submit" class="btn btn-primary" name="updatetboxone" value="EDIT">Save Changes</button>
                </div>
              </div>
									 
                 </form>
				 <p><strong>Tips</strong>Try to write thoughts in Thoughtbox1 , 2  , 3 of same lenght for better look. </p>
				 
		


                <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>		
				 
</body>
</html>

              <?php
			     
				 
                         if(isset($_POST['updatetboxone']))  {
                             
							 
					    //getting text data from the fields
                              $updatetone_id = $quoteone_id;						
                              $quoteone_line = $_POST['quoteone_line'];
                              $quoteone_footer = $_POST['quoteone_footer'];

						 $update_tone = "update  quoteone set quoteone_line='$quoteone_line', quoteone_footer='$quoteone_footer'  where  quoteone_id='$updatetone_id'  ";
				
						 $update_quoteone = mysqli_query($con, $update_tone);
						  
						  if($update_quoteone) {
						  
						  
             				echo"<script>alert ('Thoughtbox1  has been updated.')</script>";
             				echo"<script>window.open('index.php?edit_thoughtbox1' ,'_self')</script>";
							
							}
						  
                  }
				  
				  
                      ?>








						   

	 