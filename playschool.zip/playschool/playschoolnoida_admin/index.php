<?php

include("includes/db.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>PlaySchool </title>
	<meta name="description" content="playschoolnoida">
	<!-- Latest compiled and minified CSS -->
	 <!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
</head>

	<style>
	  
		
	
	</style>

<body >
          <div class="jumbotron">
  		<div class="container text-center">
  			
			<img src="../playschool-images/cms.jpg" alt="banner" class="img-responsive" >
			
	  </div><!--container closed-->
			
			</div><!--jumbotrn closed-->

             
			 <div class="row">
                   <div class="col-md-3">
				   
				      <div class="list-group text-center ">
					        
							<a href="#" class="list-group-item active">Log Out</a>
                           <a href="index.php?view_admission" class="list-group-item ">View Admission form</a>
                           <a href="index.php?view_callback" class="list-group-item">View Request Call</a>
                           <a href="index.php?view_gallery" class="list-group-item">Edit Gallery</a>									  						   
                           <a href="index.php?edit_vision=<?php $vision_id;?>" class="list-group-item">Edit Vision</a>						   
						   <a href="index.php?edit_thoughtbox1" class="list-group-item">Edit Thoughtbox1</a>                           
                           <a href="#" class="list-group-item">Edit Thoughtbox2</a>
                           <a href="#" class="list-group-item">Edit Thoughtbox3</a>						   						   
                           <a href="index.php?edit_playgroup=<?php $vision_id;?>" class="list-group-item">Edit Playgroup Section</a>
                           <a href="#" class="list-group-item">Edit Lkg Section</a>
                           <a href="#" class="list-group-item">Edit Ukg Section</a>
                           <a href="#" class="list-group-item">Edit Playgroup Box</a>
                           <a href="#" class="list-group-item">Edit LKG box</a>
                           <a href="#" class="list-group-item">Edit UKG box</a>
                           <a href="#" class="list-group-item">Edit Address</a>
                      
						   
						   
                      </div>
				   
				    </div>
				   
                   <div class="col-md-9">
				   
				           <div class="well well-lg">
						   
						       <h2 >Admin Panel</h2>
						        
								<?php
								             
											  if (isset($_GET['view_admission'])) {
			    
	                                          include("includes/view_admission.php");		  
			  
			                              }
											 
											  if (isset($_GET['view_callback'])) {
			    
	                                          include("includes/view_callback.php");		  
			  
			                              }
										  
										   if (isset($_GET['view_gallery'])) {
			    
	                                          include("includes/view_gallery.php");		  
			  
			                              }
										  
										   if (isset($_GET['edit_gallery'])) {
			    
	                                          include("includes/edit_gallery.php");		  
			  
			                              }
								
								
						                      if (isset($_GET['edit_vision'])) {
			    
	                                          include("includes/edit_vision.php");		  
			  
			                              }
										  
										       			 
						                      if (isset($_GET['edit_thoughtbox1'])) {
			    
	                                          include("includes/edit_thoughtbox1.php");		  
			  
			                              }
						         ?>   
						   </div>
				   
				   
				   </div>
				   
             </div><!--row end here-->
			 
			 

	<script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</body>	
</html>

